#include "adc.h"
#include "can.h"
#include "clcd.h"
// #include "digital_keypad.h"
#include "ecu1_sensor.h"
#include "mkp.h"
#include "msg_id.h"
#include "uart.h"

void main(void) {

  unsigned char speed[3];
  init_adc();
  init_mkp();
  init_clcd();
  init_can();
  while (1) {
    get_speed();
    get_gear_pos();
  }
}
